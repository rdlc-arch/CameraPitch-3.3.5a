-- Key Bindings menu labels
BINDING_HEADER_CAMERAPITCH = "Camera Pitch"
BINDING_NAME_CAMERAPITCH_UP = "Camera Look Up"
BINDING_NAME_CAMERAPITCH_DOWN = "Camera Look Down"
BINDING_NAME_CAMERAPITCH_LEFT = "Camera Pan Left (no turn)"
BINDING_NAME_CAMERAPITCH_RIGHT = "Camera Pan Right (no turn)"

-- Speed control: /campitch <pitch speed> [yaw speed]
local f = CreateFrame("Frame")
f:RegisterEvent("VARIABLES_LOADED")
f:SetScript("OnEvent", function()
	CameraPitchDB = CameraPitchDB or {}
	if CameraPitchDB.pitch then SetCVar("cameraPitchMoveSpeed", CameraPitchDB.pitch) end
	if CameraPitchDB.yaw then SetCVar("cameraYawMoveSpeed", CameraPitchDB.yaw) end
	if CameraPitchDB.follow == nil then CameraPitchDB.follow = true end
end)

-- Make the game's own Pitch Up/Down binds (Key Bindings > Movement) also tilt the camera,
-- like right-click + mouse up/down. Hooks run after the protected call, so nothing is blocked.
hooksecurefunc("PitchUpStart",   function() if CameraPitchDB and CameraPitchDB.follow then MoveViewDownStart() end end)
hooksecurefunc("PitchUpStop",    function() MoveViewDownStop() end)
hooksecurefunc("PitchDownStart", function() if CameraPitchDB and CameraPitchDB.follow then MoveViewUpStart() end end)
hooksecurefunc("PitchDownStop",  function() MoveViewUpStop() end)

SLASH_CAMERAPITCH1 = "/campitch"
SlashCmdList["CAMERAPITCH"] = function(msg)
	if msg:lower() == "follow" then
		CameraPitchDB.follow = not CameraPitchDB.follow
		print("CameraPitch: camera follows Pitch Up/Down = " .. tostring(CameraPitchDB.follow))
		return
	end
	local p, y = msg:match("^(%S+)%s*(%S*)$")
	p, y = tonumber(p), tonumber(y)
	if not p then
		print("CameraPitch: pitch speed = " .. GetCVar("cameraPitchMoveSpeed")
			.. ", yaw speed = " .. GetCVar("cameraYawMoveSpeed"))
		print("Usage: /campitch <pitch speed> [yaw speed]   (e.g. /campitch 60 120)")
		print("       /campitch follow   - toggle camera tilt on the game's Pitch Up/Down binds")
		return
	end
	SetCVar("cameraPitchMoveSpeed", p); CameraPitchDB.pitch = p
	if y then SetCVar("cameraYawMoveSpeed", y); CameraPitchDB.yaw = y end
	print("CameraPitch: speed set.")
end
